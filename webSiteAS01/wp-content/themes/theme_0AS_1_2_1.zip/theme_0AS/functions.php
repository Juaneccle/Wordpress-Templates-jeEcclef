<?php

/**
* Wordpress Naked, a very minimal wordpress theme designed to be used as a base for other themes.
*
* @licence LGPL
* @author Darren Beale - http://siftware.co.uk - bealers@gmail.com - @bealers
*
* Project URL http://code.google.com/p/wordpress-naked/
*/

/**
* naked_nav()
*
* @desc a wrapper for the wordpress wp_list_pages() function that
* will display one or two unordered lists:
* 1) primary nav, a ul with css id #nav - always shown even if empty
* 2) Optional secondary nav, a ul with css id #subNav
*
* @todo default css provided to allow space for both nav 'bars' one below the other to stop the page jig
*
* @param obj post
* @return string (html)
*/

require get_template_directory() . '/assets/inc/query.php';
function naked_nav($post = 0)
{
  $output = "";
  $subNav = "";
  $params = "title_li=&depth=1&echo=0";

  // always show top level
  $output .= '<ul id="nav" class="nav navbar-nav mainMenu">';
  $output .= wp_list_pages($params);
  $output .= '</ul>';

  // second level?
  if($post->post_parent)
  {
    $params .= "&child_of=" . $post->post_parent;
  }
  else
  {
    $params .= "&child_of=" . $post->ID;
  }
  $subNav = wp_list_pages($params);

  if ($subNav)
  {
    $output .= '<ul id="subNav">';
    $output .= $subNav;
    $output .= '</ul>';
  }
  return $output;
}

/**
* @desc make the site's heading & tagline an h1 on the homepage and an h4 on internal pages
* Naked's default CSS should make the two different states look identical
*/


/**
* register_sidebar()
*
*@desc Registers the markup to display in and around a widget
*/
if ( function_exists('register_sidebar') )
{
  register_sidebar(array(
    'name' => __( 'Rigth Sidebar', 'theme-slug' ),
    'before_widget' => '<li id="%1$s" class="widget %2$s">',
    'after_widget' => '</li>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
  ));

  register_sidebar(array(
    'name' => __( 'Left Sidebar', 'theme-slug' ),
    'before_widget' => '<li id="%1$s" class="widget %2$s">',
    'after_widget' => '</li>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
  ));
}

/**
* Check to see if this page will paginate
*
* @return boolean
*/
function will_paginate()
{
  global $wp_query;

  if ( !is_singular() )
  {
    $max_num_pages = $wp_query->max_num_pages;

    if ( $max_num_pages > 1 )
    {
      return true;
    }
  }
  return false;
}

//register Menu

add_action( 'after_setup_theme', 'register_my_menu' );
function register_my_menu() {
  register_nav_menu( 'PrimerMenu','menu navegacion header', __( 'PrimerMenu Menu', 'theme-slug' ) );
}

add_action( 'after_setup_theme', 'rigistra_orientacion' );
function rigistra_orientacion() {
  register_nav_menu( 'menuOrientacion','menu para navegar en categorias', __( 'menuOrientacion Menu', 'theme-slug' ) );
}
//

add_theme_support( 'post-thumbnails' );

//




add_action( 'init', 'create_post_type_noticias' );
function create_post_type_noticias() {
	register_post_type( 'Noticia',
		array(
			'labels' => array(
				'name' => __( 'Portafolio' ),
				'singular_name' => __( 'Noticia' )
			),
		'public' => true,
		'has_archive' => true,
		'supports' => array( 'title', 'editor', 'excerpt', 'custom-fields', 'thumbnail','comments','author'),
		'taxonomies' => array('category', 'post_tag') // this is IMPORTANT
		)
	);
}


add_action( 'init', 'create_post_type_categoria1s' );
function create_post_type_categoria1s() {
	register_post_type( 'Categoria1',
		array(
			'labels' => array(
				'name' => __( 'Categorias1ss' ),
				'singular_name' => __( 'Categoria1' )
			),
		'public' => true,
		'has_archive' => true,
		'supports' => array( 'title', 'editor', 'excerpt', 'custom-fields', 'thumbnail','comments','author'),
		'taxonomies' => array('category', 'post_tag') // this is IMPORTANT
		)
	);
}


    global $wp_query, $withcomments, $post, $wpdb, $id, $comment, $user_login, $user_ID, $user_identity, $overridden_cpage;

    if ( ! ( is_single() || is_page() || $withcomments ) || empty( $post ) ) {
        return;
    }

    if ( empty( $file ) ) {
        $file = '/comments.php';
    }
?>
