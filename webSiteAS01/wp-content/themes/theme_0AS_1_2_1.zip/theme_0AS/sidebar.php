<ul>
hola
<?php
  /**
  * only shown if widget sidebar not enabled
  */
  
  
		dynamic_sidebar( 'Rigth Sidebar' ); 

   
    ?>
    


</ul>